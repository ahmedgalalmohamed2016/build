export interface Bid {
  id: string
  nft: number
  bidPrice: number
  bidder: string
  expireTimestamp: number
  txtHash: string
  chainId: number
}
