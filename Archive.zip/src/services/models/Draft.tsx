import { NFT } from './NFT'

export interface Draft {
  user: string
  drafts: NFT[]
}
