export interface User {
  ethAddress: string
  wishlist: number[]
  name?: string
  email?: string
  details?: string
}
